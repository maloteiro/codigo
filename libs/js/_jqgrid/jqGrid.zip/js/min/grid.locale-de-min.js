/**
 * jqGrid German Translation
 * Version 1.0.0 (developed for jQuery Grid 3.3.1)
 * Olaf Klöppel opensource@blue-hit.de
 * http://blue-hit.de/ 
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
**/	
;(function($){$.jgrid={};$.jgrid.defaults={recordtext:"Zeile(n)",loadtext:"Lädt...",pgtext:"/"};$.jgrid.search={caption:"Suche...",Find:"Finden",Reset:"Zurücksetzen",odata:['gleich','ungleich','kleiner','kleiner oder gleich','größer','größer oder gleich','beginnt mit','endet mit','beinhaltet']};$.jgrid.edit={addCaption:"Datensatz hinzufügen",editCaption:"Datensatz bearbeiten",bSubmit:"Speichern",bCancel:"Abbrechen",bClose:"Schließen",processData:"Verarbeitung läuft...",msg:{required:"Feld ist erforderlich",number:"Bitte geben Sie eine Zahl ein",minValue:"Wert muss größer oder gleich sein, als ",maxValue:"Wert muss kleiner oder gleich sein, als ",email:"ist keine valide E-Mail Adresse",integer:"Bitte geben Sie eine Ganzzahl ein",date:"Please, enter valid date value"}};$.jgrid.del={caption:"Löschen",msg:"Ausgewählte Datensätze löschen?",bSubmit:"Löschen",bCancel:"Abbrechen",processData:"Verarbeitung läuft..."};$.jgrid.nav={edittext:" ",edittitle:"Ausgewählten Zeile editieren",addtext:" ",addtitle:"Neuen Zeile einfügen",deltext:" ",deltitle:"Ausgewählte Zeile löschen",searchtext:" ",searchtitle:"Datensatz finden",refreshtext:"",refreshtitle:"Tabelle neu laden",alertcap:"Warnung",alerttext:"Bitte Zeile auswählen"};$.jgrid.col={caption:"Spalten anzeigen/verbergen",bSubmit:"Speichern",bCancel:"Abbrechen"};$.jgrid.errors={errcap:"Fehler",nourl:"Keine URL angegeben",norecords:"Keine Datensätze zum verarbeiten"};})(jQuery);